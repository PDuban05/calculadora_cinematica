package com.example.tarea;

import static java.lang.Double.parseDouble;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        TextView txtresultado = findViewById(R.id.resultado);
        TextView txtresultado2 = findViewById(R.id.resultado2);


        Button c = findViewById(R.id.c);
        c.setOnClickListener(v -> {
            txtresultado.setText("0");
            txtresultado2.setText("");
        });



        Button siete = findViewById(R.id.siete);
        siete.setOnClickListener(v -> {
            String cadena,cadena2;
            cadena = txtresultado.getText().toString();
            cadena2 = txtresultado2.getText().toString();
            if(!cadena2.isEmpty()){
                txtresultado.setText(txtresultado2.getText().toString());
                txtresultado2.setText("");
                txtresultado.setText(txtresultado.getText()+("7"));

            }else if(cadena == "0"){
                txtresultado.setText("7");
            }else{
                txtresultado.setText(txtresultado.getText()+("7"));
            }
        });

        Button ocho = findViewById(R.id.ocho);
        ocho.setOnClickListener(v -> {
            String cadena,cadena2;
            cadena = txtresultado.getText().toString();
            cadena2 = txtresultado2.getText().toString();
            if(!cadena2.isEmpty()){
                txtresultado.setText(txtresultado2.getText().toString());
                txtresultado2.setText("");
                txtresultado.setText(txtresultado.getText()+("8"));

            }else if(cadena == "0"){
                txtresultado.setText("8");
            }else{
                txtresultado.setText(txtresultado.getText()+("8"));
            }
        });

        Button nueve = findViewById(R.id.nueve);
        nueve.setOnClickListener(v -> {
            String cadena,cadena2;
            cadena = txtresultado.getText().toString();
            cadena2 = txtresultado2.getText().toString();
            if(!cadena2.isEmpty()){
                txtresultado.setText(txtresultado2.getText().toString());
                txtresultado2.setText("");
                txtresultado.setText(txtresultado.getText()+("9"));

            }else if(cadena == "0"){
                txtresultado.setText("9");
            }else{
                txtresultado.setText(txtresultado.getText()+("9"));
            }
        });


        Button cuatro = findViewById(R.id.cuatro);
        cuatro.setOnClickListener(v -> {
            String cadena,cadena2;
            cadena = txtresultado.getText().toString();
            cadena2 = txtresultado2.getText().toString();
            if(!cadena2.isEmpty()){
                txtresultado.setText(txtresultado2.getText().toString());
                txtresultado2.setText("");
                txtresultado.setText(txtresultado.getText()+("4"));

            }else if(cadena == "0"){
                txtresultado.setText("4");
            }else{
                txtresultado.setText(txtresultado.getText()+("4"));
            }
        });

        Button cinco = findViewById(R.id.cinco);
        cinco.setOnClickListener(v -> {
            String cadena,cadena2;
            cadena = txtresultado.getText().toString();
            cadena2 = txtresultado2.getText().toString();
            if(!cadena2.isEmpty()){
                txtresultado.setText(txtresultado2.getText().toString());
                txtresultado2.setText("");
                txtresultado.setText(txtresultado.getText()+("5"));

            }else if(cadena == "0"){
                txtresultado.setText("5");
            }else{
                txtresultado.setText(txtresultado.getText()+("5"));
            }
        });

        Button seis = findViewById(R.id.seis);
        seis.setOnClickListener(v -> {
            String cadena,cadena2;
            cadena = txtresultado.getText().toString();
            cadena2 = txtresultado2.getText().toString();
            if(!cadena2.isEmpty()){
                txtresultado.setText(txtresultado2.getText().toString());
                txtresultado2.setText("");
                txtresultado.setText(txtresultado.getText()+("6"));

            }else if(cadena == "0"){
                txtresultado.setText("6");
            }else{
                txtresultado.setText(txtresultado.getText()+("6"));
            }
        });

        Button uno = findViewById(R.id.uno);
        uno.setOnClickListener(v -> {
            String cadena,cadena2;
            cadena = txtresultado.getText().toString();
            cadena2 = txtresultado2.getText().toString();
            if(!cadena2.isEmpty()){
                txtresultado.setText(txtresultado2.getText().toString());
                txtresultado2.setText("");
                txtresultado.setText(txtresultado.getText()+("1"));

            }else if(cadena == "0"){
                txtresultado.setText("1");
            }else{
                txtresultado.setText(txtresultado.getText()+("1"));
            }
        });


        Button dos = findViewById(R.id.dos);
        dos.setOnClickListener(v -> {
            String cadena,cadena2;
            cadena = txtresultado.getText().toString();
            cadena2 = txtresultado2.getText().toString();
            if(!cadena2.isEmpty()){
                txtresultado.setText(txtresultado2.getText().toString());
                txtresultado2.setText("");
                txtresultado.setText(txtresultado.getText()+("2"));

            }else if(cadena == "0"){
                txtresultado.setText("2");
            }else{
                txtresultado.setText(txtresultado.getText()+("2"));
            }
        });

        Button tres = findViewById(R.id.tres);
        tres.setOnClickListener(v -> {
            String cadena,cadena2;
            cadena = txtresultado.getText().toString();
            cadena2 = txtresultado2.getText().toString();
            if(!cadena2.isEmpty()){
                txtresultado.setText(txtresultado2.getText().toString());
                txtresultado2.setText("");
                txtresultado.setText(txtresultado.getText()+("3"));

            }else if(cadena == "0"){
                txtresultado.setText("3");
            }else{
                txtresultado.setText(txtresultado.getText()+("3"));
            }
        });

        Button cero = findViewById(R.id.cero);
        cero.setOnClickListener(v -> {
            String cadena,cadena2;
            cadena = txtresultado.getText().toString();
            cadena2 = txtresultado2.getText().toString();
            if(!cadena2.isEmpty()){
                txtresultado.setText(txtresultado2.getText().toString());
                txtresultado2.setText("");
                txtresultado.setText(txtresultado.getText()+("0"));

            }else if(cadena.isEmpty()){
                txtresultado.setText("0");
            }else if(!cadena.isEmpty() && cadena!="0"){
                txtresultado.setText(txtresultado.getText()+("0"));
            }
        });

        Button punto = findViewById(R.id.punto);
        punto.setOnClickListener(v -> {
            String cadena,cadena2;
            cadena = txtresultado.getText().toString();
            cadena2 = txtresultado2.getText().toString();
            if(!cadena2.isEmpty()){

            }else if(cadena.isEmpty()){
                txtresultado.setText("");
            }else{
                txtresultado.setText(txtresultado.getText()+("."));
            }
        });



        Button suma = findViewById(R.id.suma);
        suma.setOnClickListener(v -> {
            String cadena,cadena2;
            cadena = txtresultado.getText().toString();
            cadena2 = txtresultado2.getText().toString();

            if(!cadena2.isEmpty()){
                txtresultado.setText(txtresultado2.getText().toString());
                txtresultado2.setText("");
                txtresultado.setText(txtresultado.getText()+("+"));

                bloquear_operaciones();


            } else if(!cadena.isEmpty() && cadena!="0"){
                txtresultado.setText(txtresultado.getText()+("+"));
                bloquear_operaciones();

            }
        });

        Button resta = findViewById(R.id.resta);
        resta.setOnClickListener(v -> {
            String cadena,cadena2;
            cadena = txtresultado.getText().toString();
            cadena2 = txtresultado2.getText().toString();



            if(!cadena2.isEmpty()){
                txtresultado.setText(txtresultado2.getText().toString());
                txtresultado2.setText("");
                txtresultado.setText(txtresultado.getText()+("-"));
                bloquear_operaciones();


            } else if(!cadena.isEmpty() && cadena!="0"){
                txtresultado.setText(txtresultado.getText()+("-"));
                bloquear_operaciones();

            }
        });

        Button multiplicacion = findViewById(R.id.multiplicacion);
        multiplicacion.setOnClickListener(v -> {
            String cadena,cadena2;
            cadena = txtresultado.getText().toString();
            cadena2 = txtresultado2.getText().toString();



            if(!cadena2.isEmpty()){
                txtresultado.setText(txtresultado2.getText().toString());
                txtresultado2.setText("");
                txtresultado.setText(txtresultado.getText()+("*"));

                bloquear_operaciones();


            } else if(!cadena.isEmpty() && cadena!="0"){
                txtresultado.setText(txtresultado.getText()+("*"));

                bloquear_operaciones();

            }
        });

        Button division = findViewById(R.id.division);
        division.setOnClickListener(v -> {
            String cadena,cadena2;
            cadena = txtresultado.getText().toString();
            cadena2 = txtresultado2.getText().toString();



            if(!cadena2.isEmpty()){
                txtresultado.setText(txtresultado2.getText().toString());
                txtresultado2.setText("");
                txtresultado.setText(txtresultado.getText()+("/"));

                bloquear_operaciones();


            } else if(!cadena.isEmpty() && cadena!="0"){
                txtresultado.setText(txtresultado.getText()+("/"));

                bloquear_operaciones();

            }
        });


        Button igual = findViewById(R.id.igual);
        igual.setOnClickListener(v -> {
            String cadena, n1,n2;
            cadena = txtresultado.getText().toString();

            double num1,num2,resultado;
            int operadorsuma = cadena.indexOf("+",0);
            int operadorresta = cadena.indexOf("-",0);
            int operadormultiplicacion = cadena.indexOf("*",0);
            int operadordivision = cadena.indexOf("/",0);


            if(!cadena.isEmpty() && operadorsuma!=-1 ){

                n1 =  cadena.substring(0,operadorsuma);
                n2 = cadena.substring(operadorsuma+1);


                num1 = parseDouble(n1);
                num2 = parseDouble(n2);
                resultado = num1 + num2;
                txtresultado2.setText(String.valueOf(resultado));

                suma.setEnabled(true);
                multiplicacion.setEnabled(true);
                division.setEnabled(true);
                resta.setEnabled(true);

                desbloquear_operaciones();

            }

            else if(!cadena.isEmpty() && operadorresta!=-1 ){

                    n1 =  cadena.substring(0,operadorresta);
                    n2 = cadena.substring(operadorresta+1);


                    num1 = parseDouble(n1);
                    num2 = parseDouble(n2);
                    resultado = num1 - num2;
                    txtresultado2.setText(String.valueOf(resultado));

                    desbloquear_operaciones();

                } else if(!cadena.isEmpty() && operadormultiplicacion!=-1 ){

                n1 =  cadena.substring(0,operadormultiplicacion);
                n2 = cadena.substring(operadormultiplicacion+1);


                num1 = parseDouble(n1);
                num2 = parseDouble(n2);
                resultado = num1 * num2;
                txtresultado2.setText(String.valueOf(resultado));

                desbloquear_operaciones();
            }



            else if(!cadena.isEmpty() && operadordivision!=-1 ){

                n1 =  cadena.substring(0,operadordivision);
                n2 = cadena.substring(operadordivision+1);

                num1 = parseDouble(n1);
                num2 = parseDouble(n2);
                if (num2!=0){
                    resultado = num1 / num2;
                    txtresultado2.setText(String.valueOf(resultado));

                  desbloquear_operaciones();
                }

            }

        });



        Button borrar = findViewById(R.id.borrar);
        borrar.setOnClickListener(v -> {


           String cadena = txtresultado.getText().toString();
           String cadena2= txtresultado2.getText().toString();

           if(!cadena2.isEmpty()){
               txtresultado.setText(txtresultado2.getText().toString());
               txtresultado2.setText("");

           }
           else if(!cadena.isEmpty()){
               String newcadena = cadena.substring ( 0, cadena.length() - 1 );
               txtresultado.setText(newcadena);
           }



        });

    }




    public void bloquear_operaciones(){
        Button resta = findViewById(R.id.resta);
        Button multiplicacion = findViewById(R.id.multiplicacion);
        Button division = findViewById(R.id.division);
        Button suma = findViewById(R.id.suma);

        suma.setEnabled(false);
        multiplicacion.setEnabled(false);
        division.setEnabled(false);
        resta.setEnabled(false);

    }

    public void desbloquear_operaciones(){
        Button resta = findViewById(R.id.resta);
        Button multiplicacion = findViewById(R.id.multiplicacion);
        Button division = findViewById(R.id.division);
        Button suma = findViewById(R.id.suma);

        suma.setEnabled(true);
        multiplicacion.setEnabled(true);
        division.setEnabled(true);
        resta.setEnabled(true);

    }


}